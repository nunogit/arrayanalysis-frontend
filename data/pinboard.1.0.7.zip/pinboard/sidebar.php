<div id="sidebar" <?php pinboard_sidebar_class(); ?>>
	<?php get_sidebar( 'top' ); ?>
	<?php get_sidebar( 'left' ); ?>
	<?php get_sidebar( 'right' ); ?>
	<?php get_sidebar( 'bottom' ); ?>
</div><!-- #sidebar -->